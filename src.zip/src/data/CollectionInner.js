const collectionInnerBreadCrumb = [
    {
        url: "/",
        title: "Home",
        active: false,
    },
    {
        url: "/",
        title: "Commercial Ovens",
        active: false,
    },
    {
        url: "/",
        title: "Microwave Oven",
        active: false,
    },
    {
        title: "Search results for “Product Name”",
        active: true,
    }
]

export { collectionInnerBreadCrumb }