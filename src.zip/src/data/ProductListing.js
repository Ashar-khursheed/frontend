const productsCategory = [{
        url: "#",
        title: "High-Speed Commercial",
        imgSource: "/images/productListing/category.png"
    },
    {
        url: "#",
        title: "Commercial Microoven",
        imgSource: "/images/productListing/category.png"
    },
    {
        url: "#",
        title: "Residential Countertop",
        imgSource: "/images/productListing/category.png"
    },
    {
        url: "#",
        title: "Countertop Steamer",
        imgSource: "/images/productListing/category.png"
    },
    {
        url: "#",
        title: "High-Speed Commercial",
        imgSource: "/images/productListing/category.png"
    },
    {
        url: "#",
        title: "Commercial Microoven",
        imgSource: "/images/productListing/category.png"
    },
    {
        url: "#",
        title: "Residential Countertop",
        imgSource: "/images/productListing/category.png"
    },
    {
        url: "#",
        title: "Countertop Steamer",
        imgSource: "/images/productListing/category.png"
    },
]

const ListofProducts = [{
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    }, {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    }, {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    }, {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    }, {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    }
]

const relatedSearch = [
    "Toaster",
    "Microwave Food",
    "Kitchen Items",
    "Power Saving",
    "Budget Oven",
    "Mini Fridge",
    "Cooker",
    "Commercial Equipment",
    "cooker",
    "power saving"

]

const relatedProduct = [{
        redirectLink: "#",
        blogImg: "images/blog/blogImg/blog-1.png",
        writerImg: "images/blog/writer/writer-1.png",
        writtenBy: "Gabriel Kreuther",
        postedDate: "posted 08-august-2024",
        title: "Lorem ipsum dolor sit amet consectetur Pharetra non feugiat habitant ",
        describe: "Lorem ipsum dolor sit amet consectetur. Odio lectus sita ai quisque a suscipit hendrerit pretium volutpat turpis non ultrices. Amet mauris quis at venenatis Eu non congue egestas convallis proin Netus sed.",
        viewCount: "1",
        commentCount: "6",
        shareCount: "1",
        isFavorite: false
    },
    {
        redirectLink: "#",
        blogImg: "images/blog/blogImg/blog-2.png",
        writerImg: "images/blog/writer/writer-2.png",
        writtenBy: " Don Bradman",
        postedDate: "posted 08-august-2024",
        title: "Lorem ipsum dolor sit amet consectetur Pharetra non feugiat habitant ",
        describe: "Lorem ipsum dolor sit amet consectetur. Odio lectus sita ai quisque a suscipit hendrerit pretium volutpat turpis non ultrices. Amet mauris quis at venenatis Eu non congue egestas convallis proin Netus sed.",
        viewCount: "1",
        commentCount: "6",
        shareCount: "1",
        isFavorite: false
    },
    {
        redirectLink: "#",
        blogImg: "images/blog/blogImg/blog-3.png",
        writerImg: "images/blog/writer/writer-3.png",
        writtenBy: "gautam Khurrana",
        postedDate: "posted 08-august-2024",
        title: "Lorem ipsum dolor sit amet consectetur Pharetra non feugiat habitant ",
        describe: "Lorem ipsum dolor sit amet consectetur. Odio lectus sita ai quisque a suscipit hendrerit pretium volutpat turpis non ultrices. Amet mauris quis at venenatis Eu non congue egestas convallis proin Netus sed.",
        viewCount: "1",
        commentCount: "6",
        shareCount: "1",
        isFavorite: false
    }
]

const productData = [{
        redirectLink: "#",
        blogImg: "images/blog/blogImg/blog-1.png",
        writerImg: "images/blog/writer/writer-1.png",
        writtenBy: "Gabriel Kreuther",
        postedDate: "posted 08-august-2024",
        title: "Lorem ipsum dolor sit amet consectetur Pharetra non feugiat habitant ",
        describe: "Lorem ipsum dolor sit amet consectetur. Odio lectus sita ai quisque a suscipit hendrerit pretium volutpat turpis non ultrices. Amet mauris quis at venenatis Eu non congue egestas convallis proin Netus sed.",
        viewCount: "1",
        commentCount: "6",
        shareCount: "1",
        isFavorite: false
    },
    {
        redirectLink: "#",
        blogImg: "images/blog/blogImg/blog-2.png",
        writerImg: "images/blog/writer/writer-2.png",
        writtenBy: " Don Bradman",
        postedDate: "posted 08-august-2024",
        title: "Lorem ipsum dolor sit amet consectetur Pharetra non feugiat habitant ",
        describe: "Lorem ipsum dolor sit amet consectetur. Odio lectus sita ai quisque a suscipit hendrerit pretium volutpat turpis non ultrices. Amet mauris quis at venenatis Eu non congue egestas convallis proin Netus sed.",
        viewCount: "1",
        commentCount: "6",
        shareCount: "1",
        isFavorite: false
    },
    {
        redirectLink: "#",
        blogImg: "images/blog/blogImg/blog-3.png",
        writerImg: "images/blog/writer/writer-3.png",
        writtenBy: "gautam Khurrana",
        postedDate: "posted 08-august-2024",
        title: "Lorem ipsum dolor sit amet consectetur Pharetra non feugiat habitant ",
        describe: "Lorem ipsum dolor sit amet consectetur. Odio lectus sita ai quisque a suscipit hendrerit pretium volutpat turpis non ultrices. Amet mauris quis at venenatis Eu non congue egestas convallis proin Netus sed.",
        viewCount: "1",
        commentCount: "6",
        shareCount: "1",
        isFavorite: false
    }
]


const recomendProduct = [{
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    }, {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
    {
        url: "#",
        isOnSale: true,
        images: [
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png",
            "/images/featureProduct/Product-1.png"
        ],
        altText: "Product",
        productName: "Millac Gold Whipping Cream12 x 1 Liter",
        ratting: 5000,
        deliveryStatus: "Free DELIVERY Get it as soon as Sunday, 8 Sep",
        currency: "USD",
        currentPrice: "245.45",
        previousPrice: "300.58",
        leftStock: 4,
        lowerOffer: "169.17"
    },
]
export { productsCategory, ListofProducts, relatedSearch, relatedProduct, productData, recomendProduct }