import React from 'react'

const Processing = () => {
  return (
    <div>Processing</div>
  )
}

export default Processing