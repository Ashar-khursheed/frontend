import React from 'react'

const Delivered = () => {
  return (
    <div>Delivered</div>
  )
}

export default Delivered