import React from 'react'

const Shipped = () => {
  return (
    <div>Shipped</div>
  )
}

export default Shipped