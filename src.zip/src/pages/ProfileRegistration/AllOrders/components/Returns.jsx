import React from 'react'

const Returns = () => {
  return (
    <div>Returns</div>
  )
}

export default Returns