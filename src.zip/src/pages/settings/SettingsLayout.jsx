import React from "react";

  const SettingsLayout = () =>{
    return(
        <div>
            
        </div>
    )
}

export default React.memo(SettingsLayout);